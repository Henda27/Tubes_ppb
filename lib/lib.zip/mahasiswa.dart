// To parse this JSON data, do
//
//     final mahasiswa = mahasiswaFromJson(jsonString);

import 'dart:convert';

List<Mahasiswa> mahasiswaFromJson(String str) =>
    List<Mahasiswa>.from(json.decode(str).map((x) => Mahasiswa.fromJson(x)));

String mahasiswaToJson(List<Mahasiswa> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toJson())));

class Mahasiswa {
  Mahasiswa(
      {this.nim, this.nama, this.kelas, this.jurusan, this.uts, this.uas});

  String nim;
  String nama;
  String kelas;
  String jurusan;
  String uts;
  String uas;

  factory Mahasiswa.fromJson(Map<String, dynamic> json) => Mahasiswa(
        nim: json["nim"],
        nama: json["nama"],
        kelas: json["kelas"],
        jurusan: json["jurusan"],
        uts: json["uts"],
        uas: json["uas"],
      );

  Map<String, dynamic> toJson() => {
        "nim": nim,
        "nama": nama,
        "kelas": kelas,
        "jurusan": jurusan,
        "uts": uts,
        "uas": uas,
      };
}
