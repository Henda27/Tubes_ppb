import 'package:flutter/material.dart';
import 'mahasiswa.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ViewJson extends StatefulWidget {
  @override
  _ViewJsonState createState() => _ViewJsonState();
}

class _ViewJsonState extends State<ViewJson> {
  @override
  void initState() {
    super.initState();
    this.getData();
    listMahasiswa;
  }

  Future<Mahasiswa> createMhs(String nim, String nama, String kelas,
      String jurusan, String uts, String uas) async {
    final String apiURL = "http://192.168.1.6/apiflutter/insert.php";
    final response = await http.post(apiURL, headers: {
      "Accept": "application/json"
    }, body: {
      "nim": nim,
      "nama": nama,
      "kelas": kelas,
      "jurusan": jurusan,
      "uts": uts,
      "uas": uas
    });

    if (response.statusCode == 200) {
      var responseString = json.decode(response.body.toString());

      return Mahasiswa.fromJson(responseString);
    } else {
      return null;
    }
  }

  List listMahasiswa = [];

  Future<String> getData() async {
    http.Response response = await http.get(
        Uri.encodeFull("http://192.168.1.6/apiflutter/list_mahasiswa.php"),
        headers: {"Accept": "application/json"});
    setState(() {
      var body = json.decode(response.body);
      listMahasiswa = body;
    });
  }

  TextEditingController _controllerNim = TextEditingController();
  TextEditingController _controllerNama = TextEditingController();
  TextEditingController _controllerkelas = TextEditingController();
  TextEditingController _controllerjurusan = TextEditingController();
  TextEditingController _controlleruts = TextEditingController();
  TextEditingController _controlleruas = TextEditingController();
  GlobalKey<ScaffoldState> _scaffold = new GlobalKey<ScaffoldState>();

  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffold,
      appBar: AppBar(
        title: Text("Parsing Json"),
      ),
      body: MediaQuery.removePadding(
        context: context,
        removeTop: true,
        child: ListView(
          padding: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
          shrinkWrap: true,
          physics: ClampingScrollPhysics(),
          children: [
            Text("Form Input"),
            Divider(
              thickness: 1,
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Flexible(
                    child: TextField(
                  controller: _controllerNim,
                  decoration: InputDecoration(hintText: "Nim"),
                )),
                SizedBox(
                  width: 10,
                ),
                Flexible(
                    child: TextField(
                  controller: _controllerkelas,
                  decoration: InputDecoration(hintText: "kelas"),
                )),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Flexible(
                    child: TextField(
                  controller: _controllerNama,
                  decoration: InputDecoration(hintText: "Nama Mhs"),
                )),
                SizedBox(
                  width: 10,
                ),
                Flexible(
                    child: TextField(
                  controller: _controllerjurusan,
                  decoration: InputDecoration(hintText: "Jurusan"),
                )),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Flexible(
                    child: TextField(
                  controller: _controlleruts,
                  decoration: InputDecoration(hintText: "Nilai UTS"),
                )),
                SizedBox(
                  width: 10,
                ),
                Flexible(
                    child: TextField(
                  controller: _controlleruas,
                  decoration: InputDecoration(hintText: "Nilai Uas"),
                )),
              ],
            ),
            SizedBox(
              height: 10,
            ),
            RaisedButton(
              onPressed: () async {
                final Mahasiswa mhs = await createMhs(
                    _controllerNim.text,
                    _controllerNama.text,
                    _controllerkelas.text,
                    _controllerjurusan.text,
                    _controlleruts.text,
                    _controlleruas.text);
              },
              child: Text(
                "Simpan",
                style: TextStyle(color: Colors.white),
              ),
              color: Colors.blue,
            ),
            SizedBox(
              height: 29,
            ),
            Text("Data Mahasiswa"),
            Divider(
              thickness: 1,
            ),
            SizedBox(
              height: 10,
            ),
            new SingleChildScrollView(
              child: Row(
                children: <Widget>[
                  Expanded(
                    child: SizedBox(
                      height: 300.0,
                      child: new ListView.builder(
                        itemCount: listMahasiswa.length,
                        itemBuilder: (BuildContext ctxt, int index) {
                          return new Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 10,
                              ),
                              Text("Nim Mhs \n ${listMahasiswa[index]['nim']}"),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                  "Nama Mhs \n ${listMahasiswa[index]['nama']}"),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                  "Kelas Mhs \n ${listMahasiswa[index]['kelas']}"),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                  "Jurusan Mhs \n ${listMahasiswa[index]['jurusan']}"),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                  "Nilai Uts \n ${listMahasiswa[index]['uts']}"),
                              SizedBox(
                                height: 5,
                              ),
                              Text(
                                  "Nilai Uas \n ${listMahasiswa[index]['uas']}"),
                              // Fungsi Untuk Mengecek Apakah Mahasiswa yang bersangkutan lulus ngga
                              (int.parse(listMahasiswa[index]['uts']) +
                                              int.parse(listMahasiswa[index]
                                                  ['uas'])) /
                                          2 >
                                      75
                                  ? Text("Status : LULUS")
                                  : Text("Status : Gagal"),
                              SizedBox(
                                height: 50,
                              ),
                              Divider(
                                thickness: 2,
                              )
                            ],
                          );
                        },
                      ),
                    ),
                  ),
                ],
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
              ),
            )
          ],
        ),
      ),
    );
  }
}
